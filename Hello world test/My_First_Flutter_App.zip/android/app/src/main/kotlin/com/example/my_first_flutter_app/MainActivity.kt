package com.example.my_first_flutter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
